package _08_While_DoWhile;

public class Q17_OCAType {

    /*
aşağıdaki kod bloğunun çıktısı ne olur?
 */
    public static void main(String[] args) {

        int i = 3;
        while (i < 6) {

            i += 1;
            System.out.println(i);
        }

    }
}

// A) 3
//    4
//    5
//    6

// B) 3
//    4
//    5

// C) 1
//    2
//    3
//    4
//    5
